
public interface MovableAdapter {
	double getSpeed();
	
		double getPrice();
}
