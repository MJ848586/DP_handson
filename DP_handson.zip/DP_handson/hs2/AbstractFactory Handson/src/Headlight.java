
public abstract class Headlight {

}
